// GenerateEngine.ts
// AI passes selected objects into here using and array of objects
// objects dimensions and path collected from json and rules 
// constructs new grid and runs placement engine one object at a time
// if all objects placed successfully return placed objects position to be passed to editor
// else return failures
// 

// import { wallHeight } from "@/utils/3d-canvas/const";
import { GridManager } from "./GridManager";
import { PlacementEngine, WorldObject } from "./PlacementEngine";

// Room setup defaults
const roomWidth = 8;    // meters
const roomDepth = 6;    // meters
const cellSize = 0.25;  // finer precision
const wallHeight = 10;

// Types
interface ObjectToPlace {
  name: string; //recieves from AI filtering just object name, like "BedBasic"
}
const objectsToPlace: ObjectToPlace[] = [
  { name: "BookStackBasic" },
  { name: "WaterBottle" },
  { name: "armchair" },
  { name: "BedBasic" },
  { name: "BedsideTableBasic" },
  { name: "BookshelfBasic" }
];

export class GenerateEngine {
  grid: GridManager;
  engine: PlacementEngine;

 // construct new grid and placement engine
  constructor(
    private width: number = roomWidth,
    private depth: number = roomDepth
  ) {
    this.grid = new GridManager(this.width, this.depth, cellSize);
    this.engine = new PlacementEngine({
      grid: this.grid,
      roomWidth: this.width,
      roomDepth: this.depth,
      wallHeight,
      cellSize
    });
  }

  /**
   * Load asset manifest (once per call)
   */
  private async loadManifest() {
    const res = await fetch("/assetsManifest.json");
    if (!res.ok) throw new Error("Failed to load assetManifest.json");
    return res.json();
  }

  /**
   * Build a WorldObject from manifest + meta ie add paths and dimensions
   */
  private async buildWorldObject(name: string, manifest: any[]): Promise<WorldObject> {
    const entry = manifest.find((m) => m.name === name);
    if (!entry) throw new Error(`Object ${name} not found in manifest`);

    // Load meta.json for dimensions + rules
    const metaRes = await fetch(entry.meta);
    if (!metaRes.ok) throw new Error(`Failed to load meta for ${name}`);
    const meta = await metaRes.json();

    return {
      name: entry.name,
      path: entry.path,
      dimensions: meta.dimensions,  
      rules: [],       
    };
  }

  /**
   * Place objects one by one
   */
  async placeObjects(objects: ObjectToPlace[]) {
    const manifest = await this.loadManifest();

    // create a array of objects to place
    const worldObjects: WorldObject[] = [];

    for (const obj of objects) {
      const built = await this.buildWorldObject(obj.name, manifest);
      worldObjects.push(built);
    }

    // Run placement
    const { placed, failures } = this.engine.placeSequential(worldObjects);

    return { placed, failures };
    console.log("GenerateEngine.ts: ", this.placeObjects(objectsToPlace));  

  }

}
  